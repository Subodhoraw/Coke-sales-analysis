# Video Presentation Outline

Target duration: approximately 5–7 minutes. Adapt the script after the dashboard and final findings are complete.

## 1. Introduction

Introduce the business question: how can Coca-Cola optimise sales and operating profitability across U.S. retailers, regions, brands, and time?

## 2. Dataset understanding

Explain that the supplied workbook contains 3,888 transaction records, 13 fields, four retailers, six beverage brands, five regions, and dates from January through December 2021.

## 3. Preparation

Demonstrate how the source data was reviewed, typed, checked, structured, and how exceptional records were flagged. Explain that the two zero-sales/zero-unit rows with a recorded 40% margin were investigated rather than automatically deleted.

## 4. Exploratory analysis

Use PivotTables and charts to discuss retailer, region, brand, and monthly performance. Quote only final values verified in the completed workbook.

## 5. Profitability

Explain the difference between revenue, operating profit, and operating margin. Use weighted margin (total profit divided by total sales) for aggregate comparisons.

## 6. Interactive dashboard

Demonstrate KPI cards, charts, slicers, and date filters. Change a slicer selection and show how the visuals update.

## 7. Recommendations and close

Give a small number of practical, evidence-backed recommendations. Acknowledge that the source covers one year, so a recurring seasonal trend cannot be established from this dataset alone.
