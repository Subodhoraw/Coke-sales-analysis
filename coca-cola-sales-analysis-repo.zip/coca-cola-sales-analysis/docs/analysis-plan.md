# Analysis Plan

## 1. Business questions

1. How does sales revenue vary by retailer, region, state, and beverage brand?
2. Which retailers contribute the most revenue and operating profit?
3. How do unit price and volume relate to total sales?
4. How does operating profitability vary across retailers, regions, brands, and months?
5. What monthly patterns are visible in the 2021 data?

## 2. Preparation and controls

- Preserve an untouched copy of the original `Data` sheet.
- Convert the transaction range into a named Excel Table (for example, `tblCokeSales`).
- Standardise headers and category text; document all changes.
- Confirm date, integer, decimal, and percentage types.
- Check blanks, duplicates, negatives, and out-of-range values.
- Reconcile `Total Sales` against `Price per Unit × Units Sold` if the source definition implies that relationship.
- Flag exceptional records; do not silently delete them.

## 3. Core measures

- **Total Sales:** sum of `Total Sales`.
- **Units Sold:** sum of `Units Sold`.
- **Operating Profit:** sum of `Operating Profit`.
- **Weighted Operating Margin:** total operating profit ÷ total sales. Guard against a zero denominator.
- **Average Selling Price (ASP):** total sales ÷ total units sold, where units sold is non-zero.

Example structured-reference formulas (adjust table/field names if the imported headers differ):

```excel
=SUM(tblCokeSales[Total Sales])
=SUM(tblCokeSales[Units Sold])
=SUM(tblCokeSales[Operating Profit])
=IFERROR(SUM(tblCokeSales[Operating Profit])/SUM(tblCokeSales[Total Sales]),0)
=IFERROR(SUM(tblCokeSales[Total Sales])/SUM(tblCokeSales[Units Sold]),0)
```

## 4. PivotTable views

- Sales and profit by retailer
- Sales, units, and weighted margin by region
- Sales by state and city
- Sales and units by beverage brand
- Monthly sales and operating profit trend
- Retailer × brand and region × brand comparisons

For weighted margin in PivotTables, aggregate operating profit and total sales, then divide the totals. Avoid averaging the row-level margin percentages unless the analysis explicitly requires an unweighted average.

## 5. Dashboard design

- KPI cards across the top
- Retailer comparison bar chart
- Region comparison bar chart or map/heatmap-style view
- Monthly sales line chart
- Brand contribution chart
- Margin comparison chart
- Slicers for retailer, region, state, and brand
- Timeline or date filter where available

## 6. Interpretation safeguards

- The source covers one calendar year (2021); do not claim a recurring multi-year seasonal pattern.
- Distinguish revenue from profit and margin.
- Check that comparisons are made at equivalent grains and that differences in retailer/region coverage are understood.
- Do not infer causality from descriptive comparisons alone.
- Validate every displayed KPI against the source data before publishing.

## 7. Completion checklist

- [ ] Cleaned table and transformation steps documented
- [ ] Exceptions investigated and treatment documented
- [ ] PivotTables reconcile to source totals
- [ ] Dashboard filters work across all intended visuals
- [ ] KPI definitions and units are visible
- [ ] Business recommendations are backed by displayed evidence
- [ ] Video walkthrough recorded
