# Data Dictionary

The definitions below describe the fields present in the supplied `Data` worksheet. Confirm exact business definitions against the source provider if an official data dictionary becomes available.

| Field | Description | Suggested data type | Validation / analysis use |
|---|---|---|---|
| Retailer | Retail business name | Text | Standardise spelling and whitespace; group sales by retailer |
| Retailer ID | Retailer identifier | Whole number or text identifier | Check consistency and uniqueness at the appropriate retailer grain |
| Invoice Date | Transaction invoice date | Date | Validate date range; derive month and year |
| Region | U.S. sales region | Text/category | Standardise labels; compare regional results |
| State | U.S. state | Text/category | Validate against approved state list |
| City | Sales city | Text/category | Standardise spelling and whitespace |
| Beverage Brand | Beverage brand | Text/category | Standardise labels; compare brand contribution |
| Price per Unit | Price per item | Decimal number | Check non-negative values and plausible ranges |
| Units Sold | Units sold | Whole number | Check non-negative values; investigate zero-volume records |
| Total Sales | Recorded revenue | Decimal number | Reconcile against price × units where applicable |
| Operating Profit | Recorded operating profit | Decimal number | Check arithmetic and business validity |
| Operating Margin | Operating margin ratio/percentage | Percentage or decimal ratio | Confirm source scale; calculate weighted margin from profit / sales |
| Month | Month number | Whole number | Validate against Invoice Date; use for monthly aggregation |

## Grain

The dataset is transaction-level. Each row describes sales for a retailer, invoice date, location, and beverage brand. The source does not provide a unique transaction identifier in the documented field list; use a composite-key check only after confirming the intended record grain.

## Data-quality exception

Two rows were observed with zero units and zero total sales but a recorded 40% operating margin. Retain a review flag until the source definition is confirmed. A margin on zero sales is not directly interpretable as profit divided by sales.
